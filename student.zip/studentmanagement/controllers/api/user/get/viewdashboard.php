<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Enable CORS
header('Access-Control-Allow-Methods: GET');

// Database configuration
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'studentmanagement';

// Create response array
$response = array();

try {
    // Connect to the database
    $conn = new mysqli($host, $username, $password, $dbname);

    // Check database connection
    if ($conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }

    // Get the total number of classes
    $sqlClasses = "SELECT COUNT(*) AS total_classes FROM addclass";
    $resultClasses = $conn->query($sqlClasses);
    $response['classname'] = ($resultClasses->num_rows > 0) ? $resultClasses->fetch_assoc()['total_classes'] : 0;

    // Get the total number of students
    $sqlStudents = "SELECT COUNT(*) AS total_students FROM addstudent";
    $resultStudents = $conn->query($sqlStudents);
    $response['studentname'] = ($resultStudents->num_rows > 0) ? $resultStudents->fetch_assoc()['total_students'] : 0;

    // Get the total number of public notices
    $sqlPublicNotices = "SELECT COUNT(*) AS public_notices FROM notice WHERE noticefor = 'All'";
    $resultPublicNotices = $conn->query($sqlPublicNotices);
    $response['publicNotices'] = ($resultPublicNotices->num_rows > 0) ? $resultPublicNotices->fetch_assoc()['public_notices'] : 0;

    // Get the total number of class-specific notices
    $sqlClassNotices = "SELECT COUNT(*) AS class_notices FROM notice WHERE noticefor != 'All'";
    $resultClassNotices = $conn->query($sqlClassNotices);
    $response['classNotices'] = ($resultClassNotices->num_rows > 0) ? $resultClassNotices->fetch_assoc()['class_notices'] : 0;

    // Calculate total notices
    $response['totalNotices'] = $response['publicNotices'] + $response['classNotices'];

    // Close the connection
    $conn->close();

    // Send the response as JSON
    echo json_encode($response);
} catch (Exception $e) {
    // Send error response in case of exception
    echo json_encode(array('error' => $e->getMessage()));
}
?>
