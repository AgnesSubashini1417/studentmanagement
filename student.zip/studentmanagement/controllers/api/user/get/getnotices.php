<?php
// Enable CORS for local development
header("Access-Control-Allow-Origin: http://localhost:5173"); // React app's origin
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); // Allowed HTTP methods
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With"); // Allowed headers
header("Access-Control-Allow-Credentials: true"); // Allow cookies and session data
header("Content-Type: application/json");

// Handle preflight (OPTIONS) request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);  // Respond with 200 OK for OPTIONS request
    exit();
}

// Start session for managing logged-in state
session_start();

// Check if the session contains the student ID and class
if (!isset($_SESSION['studentid']) || !isset($_SESSION['studentclass'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(["error" => "Unauthorized access. Session data not set."]);
    exit();
}

// Database connection parameters
$host = "localhost";
$username = "root";
$password = "";
$dbname = "studentmanagement";
$conn = new mysqli($host, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Fetch student data using session-stored student ID and class
$studentid = $_SESSION['studentid'];
$studentclass = $_SESSION['studentclass']; // Getting the student class from session

// Query to fetch notices where the student class matches the noticefor field
$query = "SELECT noticetitle, noticemessage, timestamp FROM notice WHERE noticefor = ? OR noticefor = 'All'";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $studentclass); // Bind student class to the query
$stmt->execute();
$result = $stmt->get_result();

// Check if notices exist for the given student class
$notices = [];
while ($row = $result->fetch_assoc()) {
    // Add the notice to the notices array
    $notices[] = $row;
}

// If notices are found, send them in the response
if (count($notices) > 0) {
    echo json_encode(["data" => $notices]);
} else {
    http_response_code(404); // Not Found
    echo json_encode(["message" => "No notices found for this student class"]);
}

$stmt->close();
$conn->close();
?>
