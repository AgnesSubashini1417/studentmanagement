<?php
// Enable CORS for local development
header("Access-Control-Allow-Origin: http://localhost:5173"); // React app's origin
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); // Allowed HTTP methods
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With"); // Allowed headers
header("Access-Control-Allow-Credentials: true"); // Allow cookies and session data
header("Content-Type: application/json");

// Handle preflight (OPTIONS) request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);  // Respond with 200 OK for OPTIONS request
    exit();
}

// Start session for managing logged-in state
session_start();

// Database connection parameters
$host = "localhost";
$username = "root";
$password = "";
$dbname = "studentmanagement";
$conn = new mysqli($host, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Handle the POST request for login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Decode the JSON payload
    $input = json_decode(file_get_contents("php://input"), true);

    $studentname = $input['studentname'] ?? null;
    $studentid = $input['studentid'] ?? null;

    // Validate input
    if ($studentname && $studentid) {
        // Check for a matching user in the database
        $query = "SELECT * FROM addstudent WHERE studentname = ? AND studentid = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $studentname, $studentid);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Login successful, set session variables
            $row = $result->fetch_assoc();
            $_SESSION['studentid'] = $studentid;
            $_SESSION['studentname'] = $studentname;
            $_SESSION['studentclass'] = $row['studentclass'];  // Set student class in session

            http_response_code(200);
            echo json_encode(["message" => "Login successful", "studentid" => $studentid]);
        } else {
            http_response_code(401); // Unauthorized
            echo json_encode(["error" => "Invalid username or student ID"]);
        }

        $stmt->close();
    } else {
        http_response_code(400); // Bad request
        echo json_encode(["error" => "Username and student ID are required"]);
    }
} else {
    http_response_code(405); // Method not allowed
    echo json_encode(["error" => "Invalid request method"]);
}

$conn->close();
?>
