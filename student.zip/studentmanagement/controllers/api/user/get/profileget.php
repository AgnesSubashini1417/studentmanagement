<?php
// Enable CORS for local development
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Start the session
session_start();

// Handle preflight (OPTIONS) requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Check if the session contains the student ID
if (!isset($_SESSION['studentid'])) {
    http_response_code(401); // Unauthorized
    echo json_encode([
        "error" => "Unauthorized access. Session data not set.",
        "session" => $_SESSION // Debugging: output session data
    ]);
    exit();
}

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$dbname = "studentmanagement";
$conn = new mysqli($host, $username, $password, $dbname);

// Check database connection
if ($conn->connect_error) {
    http_response_code(500); // Internal Server Error
    echo json_encode(["error" => "Database connection failed"]);
    exit();
}

// Fetch student data using session-stored student ID
$studentid = $_SESSION['studentid'];
$query = "SELECT studentid, studentname, studentclass, section, Gender, Date FROM addstudent WHERE studentid = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $studentid);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $studentData = $result->fetch_assoc();
    echo json_encode(["data" => $studentData]);
} else {
    http_response_code(404); // Not Found
    echo json_encode(["error" => "Student not found"]);
}

$stmt->close();
$conn->close();
