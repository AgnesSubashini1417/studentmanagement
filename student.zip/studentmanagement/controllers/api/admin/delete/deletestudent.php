<?php

// Set headers to allow CORS
header('Access-Control-Allow-Origin: http://localhost:5173'); // Allow only your React app's origin
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS'); // Allow necessary HTTP methods
header('Access-Control-Allow-Headers: Content-Type, Authorization'); // Allow necessary headers
header('Content-Type: application/json'); // Set response content type

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection setup
$host = 'localhost'; // Your database host (usually 'localhost')
$dbname = 'studentmanagement'; // Your database name
$username = 'root'; // Your database username
$password = ''; // Your database password

// Create a PDO instance for database connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Set error mode to exception
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC); // Fetch results as associative arrays
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
    exit; // Stop execution if the database connection fails
}

// Check for DELETE request method and process
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Get the raw POST data from the DELETE request
    $data = json_decode(file_get_contents("php://input"), true);
    $studentId = isset($data['id']) ? $data['id'] : null;

    if ($studentId) {
        try {
            // Prepare and execute the deletion query
            $stmt = $pdo->prepare("DELETE FROM addstudent WHERE id = :id");
            $stmt->bindParam(':id', $studentId, PDO::PARAM_INT);
            $stmt->execute();

            // Check if any rows were deleted
            if ($stmt->rowCount() > 0) {
                echo json_encode(['message' => 'Student deleted successfully.']);
            } else {
                echo json_encode(['error' => 'Student not found or already deleted.']);
            }
        } catch (Exception $e) {
            echo json_encode(['error' => 'Failed to delete student: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['error' => 'Student ID is required.']);
    }
} else {
    // Return error response for invalid request method
    echo json_encode(['error' => 'Invalid request method.']);
}
?>
