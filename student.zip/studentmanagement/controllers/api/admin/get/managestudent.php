<?php

// Set headers to allow CORS
header('Access-Control-Allow-Origin: http://localhost:5173'); // Allow only your React app's origin
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS'); // Allow necessary HTTP methods
header('Access-Control-Allow-Headers: Content-Type, Authorization'); // Allow necessary headers
header('Content-Type: application/json'); // Set response content type

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection setup
$host = 'localhost'; // Your database host (usually 'localhost')
$dbname = 'studentmanagement'; // Your database name
$username = 'root'; // Your database username
$password = ''; // Your database password

// Create a PDO instance for database connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Set error mode to exception
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC); // Fetch results as associative arrays
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
    exit; // Stop execution if the database connection fails
}

// Handle GET request to fetch students
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // Fetch all students from the database
        $stmt = $pdo->query("SELECT * FROM addstudent");
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($students) {
            echo json_encode($students); // Send student data as JSON response
        } else {
            echo json_encode(['error' => 'No students found.']);
        }
    } catch (Exception $e) {
        echo json_encode(['error' => 'Failed to fetch students: ' . $e->getMessage()]);
    }
} else {
    // Return error response for invalid request method
    echo json_encode(['error' => 'Invalid request method.']);
}
?>
