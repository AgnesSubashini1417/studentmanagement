<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, PUT, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$host = "localhost";
$username = "root";
$password = "";
$dbname = "studentmanagement";

// Database connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Get student ID from query parameter
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch student details
    if ($id > 0) {
        $query = "SELECT * FROM addstudent WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $studentData = $result->fetch_assoc();
            echo json_encode($studentData);
        } else {
            http_response_code(404);
            echo json_encode(["error" => "Student not found."]);
        }

        $stmt->close();
    } else {
        http_response_code(400);
        echo json_encode(["error" => "Invalid student ID."]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update student details
    $input = json_decode(file_get_contents("php://input"), true);

    $studentid = $input['studentid'] ?? null;
    $studentname = $input['studentname'] ?? null;
    $studentclass = $input['studentclass'] ?? null;
    $section = $input['section'] ?? null;
    $Gender = $input['Gender'] ?? null;
    $Date = $input['Date'] ?? null;

    if ($id > 0 && $studentid && $studentname && $studentclass && $section && $Gender && $Date) {
        $query = "UPDATE addstudent SET studentid = ?, studentname = ?, studentclass = ?, section = ?, Gender = ?, Date = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssssi", $studentid, $studentname, $studentclass, $section, $Gender, $Date, $id);

        if ($stmt->execute()) {
            echo json_encode(["message" => "Student updated successfully."]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Failed to update student."]);
        }

        $stmt->close();
    } else {
        http_response_code(400);
        echo json_encode(["error" => "Invalid input or missing parameters."]);
    }
} else {
    http_response_code(405);
    echo json_encode(["error" => "Invalid request method."]);
}

$conn->close();
?>
