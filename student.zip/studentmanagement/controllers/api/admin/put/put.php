<?php
// Enable CORS for local development
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, PUT, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$dbname = "studentmanagement";

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Get class ID from query parameter
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch class details
    if ($id > 0) {
        $query = "SELECT * FROM addclass WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $classData = $result->fetch_assoc();
            echo json_encode($classData);
        } else {
            http_response_code(404);
            echo json_encode(["error" => "Class not found."]);
        }

        $stmt->close();
    } else {
        http_response_code(400);
        echo json_encode(["error" => "Invalid class ID."]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update class details
    $data = [];
    parse_str(file_get_contents("php://input"), $data);

    $classname = $data['classname'] ?? null;
    $section = $data['section'] ?? null;
    $Roomno = $data['Roomno'] ?? null;
    $strength = $data['strength'] ?? null;

    if ($id > 0 && $classname && $section && $Roomno && $strength) {
        $query = "UPDATE addclass SET classname = ?, section = ?, Roomno = ?, strength = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssii", $classname, $section, $Roomno, $strength, $id);

        if ($stmt->execute()) {
            echo json_encode(["message" => "Class updated successfully."]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Failed to update class."]);
        }

        $stmt->close();
    } else {
        http_response_code(400);
        echo json_encode(["error" => "Invalid input or missing parameters."]);
    }
} else {
    http_response_code(405); // Method not allowed
    echo json_encode(["error" => "Invalid request method."]);
}

$conn->close();
?>
