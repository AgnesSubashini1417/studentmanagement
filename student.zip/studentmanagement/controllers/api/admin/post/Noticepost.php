<?php
// Enable CORS for local development
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection parameters
$host = "localhost";
$username = "root";
$password = "";
$dbname = "studentmanagement";

// Create a connection to the database
$conn = new mysqli($host, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Handle the POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the input data
    $input = json_decode(file_get_contents("php://input"), true);

    $noticetitle = $input['noticetitle'] ?? null;
    $noticefor = $input['noticefor'] ?? null;
    $noticemessage = $input['noticemessage'] ?? null;
    $noticedate = $input['noticedate'] ?? null;

    // Validate input
    if ($noticetitle && $noticefor && $noticemessage && $noticedate) {
        // Insert the notice into the database
        $query = "INSERT INTO notice (noticetitle, noticefor, noticemessage, noticedate) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssss", $noticetitle, $noticefor, $noticemessage, $noticedate);

        if ($stmt->execute()) {
            http_response_code(201); // Created
            echo json_encode(["message" => "Notice sent successfully."]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Failed to send notice."]);
        }

        $stmt->close();
    } else {
        http_response_code(400);
        echo json_encode(["error" => "Invalid input. All fields are required."]);
    }
} else {
    http_response_code(405); // Method not allowed
    echo json_encode(["error" => "Invalid request method."]);
}

$conn->close();
?>
