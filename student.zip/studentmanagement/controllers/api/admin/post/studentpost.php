<?php
// Enable CORS for local development
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$dbname = "studentmanagement";

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(["error" => "Invalid request method."]);
    exit();
}

// Read and decode JSON input
$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['studentid'], $data['studentname'], $data['studentclass'], $data['section'], $data['Gender'], $data['Date'])) {
    http_response_code(400); // Bad Request
    echo json_encode(["error" => "Missing required fields."]);
    exit();
}

// Assign variables from input
$studentid = $data['studentid'];
$studentname = $data['studentname'];
$studentclass = $data['studentclass'];
$section = $data['section'];
$gender = $data['Gender'];
$date = $data['Date'];

// Insert query
$query = "INSERT INTO addstudent (studentid, studentname, studentclass, section, gender, Date) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);

if (!$stmt) {
    http_response_code(500); // Internal Server Error
    echo json_encode(["error" => "Prepare failed: " . $conn->error]);
    exit();
}

$stmt->bind_param("ssssss", $studentid, $studentname, $studentclass, $section, $gender, $date);

if ($stmt->execute()) {
    echo json_encode("Student Added Successfully");
} else {
    http_response_code(500); // Internal Server Error
    echo json_encode(["error" => "Failed to add student: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
