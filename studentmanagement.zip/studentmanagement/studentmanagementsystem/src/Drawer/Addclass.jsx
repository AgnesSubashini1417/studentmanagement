import React, { useState } from "react";
import axios from "axios";
import "./addclass.css";

function Addclass() {
  const [formData, setFormData] = useState({
    classname: "",
    section: "",
    Roomno: "",
    strength: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent the default form submission
    try {
      const response = await axios.post(
        "http://localhost/studentmanagement/controllers/api/admin/post/post.php", // Update this URL to match your API endpoint
        formData,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response.data === "Class Added Successfully") {
        alert("Class Added Successfully");
        // Clear the form data
        setFormData({
          classname: "",
          section: "",
          Roomno: "",
          strength: "",
        });
      } else {
        alert("Something went wrong: " + response.data);
      }
    } catch (error) {
      alert(
        error.response?.data?.error ||
          "An error occurred while adding the class."
      );
    }
  };

  return (
    <>
      {/* <div className="main-con"> */}
        <div className="containerclass">
          <h1 className="hc1">Add New Class</h1>
          <form onSubmit={handleSubmit} className="f5">
            <div className="form-group5">
              <label htmlFor="classname">Class Name:</label>
              <input
                type="text"
                id="classname"
                name="classname"
                value={formData.classname}
                required
                onChange={handleChange}
              />
            </div>
            <div className="form-group5">
              <label htmlFor="section">Section:</label>
              <input
                type="text"
                id="section"
                name="section"
                value={formData.section}
                required
                onChange={handleChange}
              />
            </div>
            <div className="form-group5">
              <label htmlFor="Roomno">Room no:</label>
              <input
                type="number"
                id="Roomno"
                name="Roomno"
                value={formData.Roomno}
                required
                onChange={handleChange}
              />
            </div>
            <div className="form-group5">
              <label htmlFor="strength">Strength:</label>
              <input
                type="number"
                id="strength"
                name="strength"
                value={formData.strength}
                required
                onChange={handleChange}
              />
            </div>
            <button className="butc1" type="submit">
              Add Class
            </button>
          </form>
        </div>
      {/* </div> */}
    </>
  );
}

export default Addclass;
