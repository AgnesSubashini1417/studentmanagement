import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './dash.css';
import { SiGoogleclassroom, SiVirustotal } from 'react-icons/si';
import { PiStudentFill } from 'react-icons/pi';
import { MdOutlineClass } from 'react-icons/md';

function Dashboard() {
  const [data, setData] = useState({
    classname: 0,
    studentname: 0,
    publicNotices: 0,
    classNotices: 0,
    totalNotices: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get('http://localhost/studentmanagement/controllers/api/user/get/viewdashboard.php')
      .then((response) => {
        setData(response.data);
        setLoading(false);
      })
      .catch((err) => {
        setError('Failed to fetch data');
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="dashboard">
      <div className="header">
        <h1>Report Summary</h1>
      </div>
      <div className="metrics">
        <div className="metric-card">
          <div className="icon-wrapper bg-green">
            <SiVirustotal />
          </div>
          <div className="metric-content">
            <div className="metric-title">Total Classes</div>
            <div className="metric-value">{data.classname}</div>
          </div>
        </div>
        <div className="metric-card">
          <div className="icon-wrapper bg-pink">
            <PiStudentFill />
          </div>
          <div className="metric-content">
            <div className="metric-title">Total Students</div>
            <div className="metric-value">{data.studentname}</div>
          </div>
        </div>
        <div className="metric-card">
          <div className="icon-wrapper bg-yellow">
            <MdOutlineClass />
          </div>
          <div className="metric-content">
            <div className="metric-title">Public Notices</div>
            <div className="metric-value">{data.publicNotices}</div>
          </div>
        </div>
        <div className="metric-card">
          <div className="icon-wrapper bg-turquoise">
            <SiGoogleclassroom />
          </div>
          <div className="metric-content">
            <div className="metric-title">Class-Specific Notices</div>
            <div className="metric-value">{data.classNotices}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
