import React, { useState } from 'react'
import "./Log.css"
import { GrLogout } from 'react-icons/gr'
import { Link } from 'react-router-dom'
import Landingpage from '../Admin/Landingpage'
export default function Logout() {
    const [hello,sethi]=useState(true)
        const Hi=()=>{
            sethi(false)
        }
  return (
   <>
   {hello ? (<div className="body-wrap">
     <div className="logout-container">
     <u>   <h1 className='H'>Logout</h1> </u>
        <p className='P'>Are you sure you want to log out?</p>
        <form action="/logout" method="POST">
            <button type="submit" className="logout-button" onClick={Hi}> <GrLogout /> Log Out</button>
        </form>
    </div>
    </div>):(<Landingpage/>)}
    
   </>
  )
}
