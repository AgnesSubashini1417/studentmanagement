import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './addclass.css';

function Editclass() {
  const [classData, setClassData] = useState({
    classname: '',
    section: '',
    Roomno: '', // Use uppercase 'R' to match the database
    strength: ''
  });

  const { id } = useParams();
  console.log(id);
  
  const navigate = useNavigate();

  useEffect(() => {
    if (!id) {
      alert('Invalid class ID');
      return;
    }
    const fetchClassData = async () => {
      try {
        const response = await fetch(`http://localhost/studentmanagement/controllers/api/admin/put/put.php?id=${id}`);
        const data = await response.json();
        if (data.classname) {
          setClassData({
            classname: data.classname,
            section: data.section,
            Roomno: data.Roomno, // Use uppercase 'R' here too
            strength: data.strength
          });
        } else {
          alert('Class not found');
        }
      } catch (error) {
        console.error('Error fetching class data:', error);
        alert('Failed to fetch class data.');
      }
    };
    fetchClassData();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { classname, section, Roomno, strength } = classData;

    try {
      const response = await fetch(`http://localhost/studentmanagement/controllers/api/admin/put/put.php?id=${id}`, {
        method: 'POST', // Change to PUT if required
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          id,
          classname,
          section,
          Roomno,
          strength
        })
      });

      const result = await response.json();

      if (result.message) {
        alert(result.message);
        navigate('/manageclass');
      } else {
        alert(result.error || 'An error occurred while updating the class');
      }
    } catch (error) {
      console.error('Error updating class:', error);
      alert('Failed to update the class. Please try again.');
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setClassData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  return (
    <div className="main-con">
      <div className="containerclass">
        <h1 className="hc">Edit Class</h1>
        <form onSubmit={handleSubmit} className="f5">
          <div className="form-group5">
            <label htmlFor="classname">Class Name:</label>
            <input
              type="text"
              id="classname"
              name="classname"
              value={classData.classname}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group5">
            <label htmlFor="section">Section:</label>
            <input
              type="text"
              id="section"
              name="section"
              value={classData.section}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group5">
            <label htmlFor="Roomno">Room No:</label>
            <input
              type="number"
              id="Roomno"
              name="Roomno"
              value={classData.Roomno}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group5">
            <label htmlFor="strength">Strength:</label>
            <input
              type="number"
              id="strength"
              name="strength"
              value={classData.strength}
              onChange={handleChange}
              required
            />
          </div>
          <button className="butc1" type="submit">Edit Class</button>
        </form>
      </div>
    </div>
  );
}

export default Editclass;
