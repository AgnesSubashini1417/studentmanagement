import React, { useState } from 'react';
import axios from 'axios';
import "./notice.css";

function Notices() {
    // State to manage form inputs
    const [formData, setFormData] = useState({
        noticetitle: '',
        noticefor: '',
        noticemessage: '',
    });

    // Handle form input changes
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    // Function to handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault(); // Prevent the default form submission behavior

        try {
            const response = await axios.post(
                'http://localhost/studentmanagement/controllers/api/admin/post/Noticepost.php', // Replace with your backend API URL
                {
                    noticetitle: formData.noticetitle,
                    noticefor:formData.noticefor,
                    noticemessage: formData.noticemessage,
                    noticedate:formData.noticedate
                },
                {
                    headers: {
                        'Content-Type': 'application/json',
                    },
                }
            );
            if (response.data) {
                alert('Notice Sent Successfully');
            }
        } catch (error) {
            console.error('Error sending notice:', error);
            alert('Failed to send notice. Please try again.');
        }
    };

    return (
        <div className="main-con">
            <div className="containerclass1">
                <h1 className="hc">Send Notice</h1>
                <form className="f5" onSubmit={handleSubmit}>
                    <div className="form-group5">
                        <label htmlFor="noticetitle">Notice Title:</label>
                        <input
                            type="text"
                            id="noticetitle"
                            name="noticetitle"
                            value={formData.noticetitle}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div className="form-group5">
                        <label htmlFor="noticefor">Notice For:</label>
                        <input
                            type="text"
                            id="noticefor"
                            name="noticefor"
                            value={formData.noticefor}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div className="form-group5">
                        <label htmlFor="noticemessage">Notice Message:</label>
                        <input
                            type="text"
                            id="noticemessage"
                            name="noticemessage"
                            value={formData.noticemessage}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div className="form-group5">
                        <label htmlFor="noticemessage">Notice Date:</label>
                        <input
                            type="date"
                            id="noticedate"
                            name="noticedate"
                            value={formData.noticedate}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <button className="butc" type="submit">
                        Send Notice
                    </button>
                </form>
            </div>
        </div>
    );
}

export default Notices;
