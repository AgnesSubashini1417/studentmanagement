import React from 'react'
import "./drawer.css"
import { MdDashboard, MdTwoWheeler } from 'react-icons/md'
import { SiGoogleclassroom } from "react-icons/si";
import { PiStudentBold } from "react-icons/pi"
import { IoMdNotifications } from "react-icons/io";

import { FaBookmark, FaCar, FaUserAlt } from 'react-icons/fa'
import { GrLogout } from 'react-icons/gr'
import { Link } from 'react-router-dom'
function Drawer() {
  return (
    <>
        <nav className="sidebar">
        <div className="logo">Admin Panel</div>
        <div className="nav-links1">
            <Link to={"/adminpanel"}><a href="#" ><MdDashboard /> Dashboard</a></Link>
            <Link to={"/class"}><a href="#"><SiGoogleclassroom /> Class</a></Link>
            <Link to={"/student"}><a href="#">< PiStudentBold /> Students</a>  </Link>
            <Link to={"/noticedb"}><a href="#"><IoMdNotifications /> Notices</a></Link>
            <Link to={"/logout"}><a href="#"><GrLogout /> Logout</a></Link>
        </div>
    </nav>
    </>
  )
}

export default Drawer