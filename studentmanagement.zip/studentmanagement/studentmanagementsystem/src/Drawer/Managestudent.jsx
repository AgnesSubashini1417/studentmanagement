import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import "./manageclass.css";

function Managestudent() {
  const [students, setStudents] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const response = await axios.get(
          "http://localhost/studentmanagement/controllers/api/admin/get/managestudent.php"
        );
        console.log(response.data); // Log the response for debugging

        if (Array.isArray(response.data)) {
          setStudents(response.data); // Set student data to state
        } else {
          // If the response is not an array, handle it as an error
          setError(response.data.error || "Failed to fetch students.");
        }
      } catch (err) {
        setError(err.message || "An error occurred while fetching data.");
        console.error(err); // Log the error for debugging
      }
    };

    fetchStudents();
  }, []);

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this student?")) {
      try {
        // Ensure you're sending the correct DELETE request format
        const response = await axios({
          method: 'delete',
          url: `http://localhost/studentmanagement/controllers/api/admin/delete/deletestudent.php`,
          data: { id: id } // Send the id as data in the body
        });
  
        console.log(response.data); // Log response from delete
  
        if (response.data.message) {
          setStudents((prevStudents) =>
            prevStudents.filter((student) => student.id !== id)
          );
        } else {
          setError("Failed to delete student.");
        }
      } catch (err) {
        setError(err.message || "Failed to delete student.");
      }
    }
  };
  

  return (
    <div className="t-row1">
      <div className="container-mana">
        <h1 className="h1a">Student Management</h1>
        {error && <p className="error">{error}</p>}
        <table>
          <thead>
            <tr>
              <th>Student ID</th>
              <th>Student Name</th>
              <th>Section</th>
              <th>Gender</th>
              <th>Date</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {students.length > 0 ? (
              students.map((student) => (
                <tr key={student.id}>
                  <td>{student.studentid}</td>
                  <td>{student.studentname}</td>
                  <td>{student.section}</td>
                  <td>{student.Gender}</td>
                  <td>{student.Date}</td>
                  <td>
                    <Link to={`/editstudent/${student.id}`}>
                      <button className="btn btn-edit">Edit</button>
                    </Link>
                  </td>
                  <td>
                    <button
                      className="btn btn-delete"
                      onClick={() => handleDelete(student.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="7">No students available</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Managestudent;
