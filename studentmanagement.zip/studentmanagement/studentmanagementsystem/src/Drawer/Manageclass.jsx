import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import "./manageclass.css";

function Manageclass() {
  const [classes, setClasses] = useState([]);
  const [error, setError] = useState("");

  // Fetch all classes from the backend
  useEffect(() => {
    const fetchClasses = async () => {
      try {
        const response = await axios.get(
          "http://localhost/studentmanagement/controllers/api/admin/get/get.php"
        );
        if (Array.isArray(response.data)) {
          setClasses(response.data); // Set classes data to state
        } else {
          setError(response.data.error || "Failed to fetch classes.");
        }
      } catch (err) {
        setError(err.message || "An error occurred while fetching data.");
      }
    };

    fetchClasses();
  }, []);

  // Handle class deletion
  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this class?")) {
      return;
    }
  
    try {
      const response = await axios.delete(
        `http://localhost/studentmanagement/controllers/api/admin/delete/delete.php?id=${id}`
      );
  
      if (response.data.message) {
        alert(response.data.message);
  
        // Remove the class from the state
        setClasses((prevClasses) => prevClasses.filter((cls) => cls.id !== id));
      } else if (response.data.error) {
        alert("Failed to delete class: " + response.data.error);
      } else {
        alert("Unexpected response from the server.");
      }
    } catch (err) {
      alert("Error deleting class: " + err.message);
    }
  };
  

  return (
    
    <div className="t-row1">
      <div className="container-mana">
        <h1 className="h1a">Class Management</h1>
        {error ? (
          <p className="error-message">{error}</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Class Name</th>
                <th>Section</th>
                <th>Room No</th>
                <th>Strength</th>
                <th>Edit</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              {classes.map((cls) => (
                <tr key={cls.id}>
                  <td data-label="Class Name">
                    <span className="class-name">{cls.classname}</span>
                  </td>
                  <td data-label="Section">{cls.section}</td>
                  <td data-label="Room No">{cls.Roomno}</td>
                  <td data-label="Strength">{cls.strength}</td>
                  <td data-label="Edit">
                    <Link to={`/editclass/${cls.id}`}>
                      <button className="btn btn-edit">Edit</button>
                    </Link>
                  </td>
                  <td data-label="Delete">
                    <button
                      className="btn btn-delete"
                      onClick={() => handleDelete(cls.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default Manageclass;
