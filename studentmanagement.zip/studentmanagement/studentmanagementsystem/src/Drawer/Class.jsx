import React from 'react'
import { Link } from 'react-router-dom'
import "./class.css"
function Class() {
  return (
   <>
   <div className="rentmain15">
   <div className="hero1">
     <div className="hero-content12">
            <div className="btn-container21">
                <Link to={"/addclass"}><a href="#" className="btn12 btn-primary1">Add Class</a>&nbsp;&nbsp;</Link>
                <Link to={"/manageclass"}><a href="#" className="btn12 btn-secondary2">Manage Class</a></Link>
            </div>
        </div>
        </div>
        </div>
   </>
  )
}

export default Class