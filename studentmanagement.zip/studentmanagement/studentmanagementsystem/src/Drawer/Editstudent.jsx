import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

function Editstudent() {
  const { id } = useParams(); // Get the student ID from the URL
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    studentid: "",
    studentname: "",
    studentclass: "",
    section: "",
    Gender: "",
    Date: "",
  });

  useEffect(() => {
    // Fetch existing student data
    if (!id) {
      alert("Invalid student ID");
      return;
    }

    const fetchStudentData = async () => {
      try {
        const response = await fetch(
          `http://localhost/studentmanagement/controllers/api/admin/put/Studentupdate.php?id=${id}`
        );
        const data = await response.json();
        if (data.studentid) {
          setFormData({
            studentid: data.studentid,
            studentname: data.studentname,
            studentclass: data.studentclass,
            section: data.section,
            Gender: data.Gender,
            Date: data.Date,
          });
        } else {
          alert("Student not found");
        }
      } catch (error) {
        console.error("Error fetching student data:", error);
        alert("Failed to fetch student data.");
      }
    };
    fetchStudentData();
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch(
        `http://localhost/studentmanagement/controllers/api/admin/put/Studentupdate.php?id=${id}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        }
      );
      const result = await response.json();

      if (result.message) {
        alert(result.message);
        navigate("/managestudent");
      } else {
        alert(result.error || "An error occurred while updating the student.");
      }
    } catch (error) {
      console.error("Error updating student:", error);
      alert("Failed to update the student. Please try again.");
    }
  };

  return (
    <div className="main-con">
      <div className="containerclass">
        <h1 className="hc">Edit Student</h1>
        <form onSubmit={handleSubmit} className="f5">
          <div className="form-group5">
            <label>Student ID:</label>
            <input
              type="text"
              name="studentid"
              value={formData.studentid}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group5">
            <label>Student Name:</label>
            <input
              type="text"
              name="studentname"
              value={formData.studentname}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group5">
            <label>Student Class:</label>
            <input
              type="text"
              name="studentclass"
              value={formData.studentclass}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group5">
            <label>Section:</label>
            <input
              type="text"
              name="section"
              value={formData.section}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group5">
            <label>Gender:</label>
            <input
              type="text"
              name="Gender"
              value={formData.Gender}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group5">
            <label>Date:</label>
            <input
              type="date"
              name="Date"
              value={formData.Date}
              onChange={handleChange}
              required
            />
          </div>
          <button className="butc1" type="submit">
            Edit Student
          </button>
        </form>
      </div>
    </div>
  );
}

export default Editstudent;
