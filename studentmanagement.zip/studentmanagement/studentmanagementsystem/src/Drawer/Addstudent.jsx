import React, { useState } from 'react';
import axios from 'axios';  // Import axios for making API requests
import "./addstudent.css";

function Addstudent() {
  const [formData, setFormData] = useState({
    studentid:"",
    studentname: "",
    studentclass: "",
    section: "",
    Gender: "",
    Date: ""
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent the default form submission
    try {
      const response = await axios.post(
        "http://localhost/studentmanagement/controllers/api/admin/post/studentpost.php", // API endpoint URL
        formData,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
  
      if (response.data === "Student Added Successfully") {
        alert("Student Added Successfully");
        setFormData({
          studentid: "",
          studentname: "",
          studentclass: "",
          section: "",
          Gender: "",
          Date: ""
        });
      } else {
        console.error("Server responded with an error:", response.data);
      }
    } catch (error) {
      // Log error to console instead of showing an alert
      console.error(
        "An error occurred while adding the student:",
        error.response?.data?.error || error.message
      );
    }
  };
  

  return (
    <>
      <div className="main-con1">
        <div className="containerclass1">
          <h1 className="hcl">Add New Student</h1>
          <form onSubmit={handleSubmit} method="post" className="f5">
          <div className="form-group5">
              <label htmlFor="studentname">Student Id:</label>
              <input
                type="number"
                id="studentid"
                name="studentid"
                value={formData.studentid}
                required
                onChange={handleChange}
              />
            </div>
            <div className="form-group5">
              <label htmlFor="studentname">Student Name:</label>
              <input
                type="text"
                id="studentname"
                name="studentname"
                value={formData.studentname}
                required
                onChange={handleChange}
              />
            </div>
            <div className="form-group5">
              <label htmlFor="studentclass">Student Class:</label>
              <input
                type="text"
                id="studentclass"
                name="studentclass"
                value={formData.studentclass}
                required
                onChange={handleChange}
              />
            </div>
            <div className="form-group5">
              <label htmlFor="studentid">Section:</label>
              <input
                type="text"
                id="studentid"
                name="section"
                value={formData.section}
                required
                onChange={handleChange}
              />
            </div>
            <div className="form-group5">
              <label htmlFor="Gender">Gender:</label>
              <select
                name="Gender"
                id="gender"
                value={formData.Gender}
                onChange={handleChange}
                required
              >
                <option value="">Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            </div>
            <div className="form-group5">
              <label htmlFor="date">Date of Birth:</label>
              <input
                type="date"
                id="date"
                name="Date"
                value={formData.Date}
                required
                onChange={handleChange}
              />
            </div>
            <button className="butc" type="submit">Add Student</button>
          </form>
        </div>
      </div>
    </>
  );
}

export default Addstudent;
