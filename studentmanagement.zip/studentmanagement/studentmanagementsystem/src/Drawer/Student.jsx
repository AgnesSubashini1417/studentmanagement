import React from 'react'
import "./class.css"
import { Link } from 'react-router-dom'
function Student() {
  return (
    <>
          <div className="rentmain15">
   <div className="hero1">
     <div className="hero-content12">
            <div className="btn-container21">
                <Link to={"/addstudent"}><a href="#" className="btn12 btn-primary1">Add Student</a>&nbsp;&nbsp;</Link>
                <Link to={"/managestudent"}><a href="#" className="btn12 btn-secondary2">Manage Students</a></Link>
            </div>
        </div>
        </div>
        </div>
    </>
  )
}

export default Student