import React, { useState } from "react";
import "./adminlogin.css";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

function UserLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
  
    setError(""); // Reset error state before making the request
  
    const payload = {
      studentname: username,
      studentid: password,
    };
  
    try {
      const response = await axios.post(
        "http://localhost/studentmanagement/controllers/api/user/get/loginget.php",
        payload,
        {
          headers: {
            "Content-Type": "application/json",
          },
          withCredentials: true, // Ensure credentials (cookies) are sent with the request
        }
      );
  
      if (response.data.message === "Login successful") {
        window.alert("Login successful");
        navigate("/userland"); // Navigate to the userland page on successful login
      } else {
        setError(response.data.error || "Login failed");
      }
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.error || "An error occurred during login");
    }
  };
  

  return (
    <div className="admin-box">
      <div className="login-container">
        <h1 className="login-title">User Login</h1>
        <form className="login-form" onSubmit={handleLogin}>
          <div className="form-group7">
            <label htmlFor="username">Username</label>
            <input
              id="username"
              name="username"
              required
              className="inp5"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
          <div className="form-group7">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              required
              className="inp5"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <div className="btn-div">
            <button type="submit" className="login-button">
              Login
            </button>
          </div>
          {error && <p className="error-message">{error}</p>}
          {/* <div className="forgot-password">
            <p>Don't Have an Account?</p> */}
            {/* <Link to={"/reg"}>
              <a href="#" id="new-register-link">
                New Register
              </a>
            </Link> */}
          {/* </div> */}
        </form>
      </div>
    </div>
  );
}

export default UserLogin;
