import React from 'react'
import "./adminlogin.css"
function Register() {
  return (
   <>
    <div className="admin-box">
        <div className="login-container">
        <h1 className="login-title">New Register</h1>
    <form className="login-form" action="#" method="post">
        <div className="form-group7">
            <label for="username">Username</label>
            <input id="username" name="username" required className='inp5'/>
        </div>
        <div className="form-group7">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required className='inp5'/>
        </div>
        <div className="form-group7">
            <label for="password">Confirm Password</label>
            <input type="password" id="password" name="password" required className='inp5'/>
        </div>
        <div className="btn-div">
        <button type="submit" className="login-button" >Register</button>
        </div>
        
    </form>
    </div>
    </div>
   </>
  )
}

export default Register