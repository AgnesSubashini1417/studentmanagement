import React from 'react'
import Drawer from '../Drawer/Drawer'
import "./admin.css"
import Dashboard from '../Drawer/Dashboard'
import { Route, Routes } from 'react-router-dom'
import Class from '../Drawer/Class'
import Student from '../Drawer/Student'
import Addclass from '../Drawer/Addclass'
import Manageclass from '../Drawer/Manageclass'
import Editclass from '../Drawer/Editclass'
import Addstudent from '../Drawer/Addstudent'
import Managestudent from '../Drawer/Managestudent'
import Editstudent from '../Drawer/Editstudent'
import Adminlogin from './Adminlogin'
import Notices from '../Drawer/Notices'
import Logout from '../Drawer/Logout'
function Adminlanding() {
  return (
    <div className="admin-div">
      <Drawer/>
      <Routes>
        
        <Route path='/adminpanel' element={<Dashboard/>}/>

        <Route path='/class' element={<Class/>}/>

        <Route path='/student' element={<Student/>}/>

        <Route path='/addclass' element={<Addclass/>}/>
        <Route path='/manageclass' element={<Manageclass/>}/>
        <Route path='/editclass/:id' element={<Editclass/>}/>

        <Route path='/addstudent' element={<Addstudent/>}/>
        <Route path='/managestudent' element={<Managestudent/>}/>
        <Route path='/editstudent/:id' element={<Editstudent/>}/>
        <Route path='/noticedb' element={<Notices/>}/>


        <Route path='/logout' element={<Logout/>}/>
      </Routes>
    </div>
  )
}

export default Adminlanding