import React, { useState } from "react";
import "./adminlogin.css";
import { Link, useNavigate } from "react-router-dom";

function Adminlogin() {
  const [submitted, setSubmit] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const Handlesub = (e) => {
    e.preventDefault(); // Prevent form submission
    if (username === "admin" && password === "123") {
      setSubmit(true);
      navigate("/adminpanel"); // Redirect to admin panel
    } else {
      alert("Invalid username or password. Please try again."); // Show alert
    }
  };

  const Handlesub2 = (e) => {
    e.preventDefault(); // Prevent form submission
    setSubmit(false);
  };

  return (
    <>
      <div className="admin-box">
        {submitted ? (
          <div className="login-container">
            <h1 className="login-title">Forget Password</h1>
            <form className="login-form" action="#" method="post">
              <div className="form-group7">
                <label htmlFor="new-password">New password</label>
                <input
                  type="password"
                  id="new-password"
                  name="new-password"
                  required
                  className="inp5"
                />
              </div>
              <div className="form-group7">
                <label htmlFor="confirm-password">Confirm Password</label>
                <input
                  type="password"
                  id="confirm-password"
                  name="confirm-password"
                  required
                  className="inp5"
                />
              </div>
              <div className="btn-div">
                <button
                  type="submit"
                  className="login-button"
                  onClick={Handlesub2}
                >
                  Reset Password
                </button>
              </div>
            </form>
          </div>
        ) : (
          <div className="login-container">
            <h1 className="login-title">Admin Login</h1>
            <form className="login-form" action="#" method="post" onSubmit={Handlesub}>
              <div className="form-group7">
                <label htmlFor="username">Username</label>
                <input
                  type="text"
                  id="username"
                  name="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="inp5"
                />
              </div>
              <div className="form-group7">
                <label htmlFor="password">Password</label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="inp5"
                />
              </div>
              <div className="btn-div">
                <button type="submit" className="login-button">
                  Login
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </>
  );
}

export default Adminlogin;
