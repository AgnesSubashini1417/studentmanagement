import React, { useState } from 'react'
import "./Land.css"
import { Link } from 'react-router-dom'
function Landingpage() {
  
  return (
    <>
   <div className="rentmain5">
        <div className="hero">
    <div className="hero-content1">
            <h1>Manage smarter. Learn better</h1>
            <p className="tagline">Your students, your control. Manage with ease.</p>
            <div className="btn-container2">
                <Link to={"/adminlog"}><a href="#" className="btn1 btn-primary1">Admin Login</a>&nbsp;&nbsp;</Link>
                <Link to={"/userlog"}><a href="#" className="btn1 btn-secondary2">User Login</a></Link>
            </div>
        </div>
        </div>
    </div>
    </>
  )
}

export default Landingpage