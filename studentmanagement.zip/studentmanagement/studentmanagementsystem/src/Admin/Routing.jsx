import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Adminlogin from './Adminlogin'
import Landingpage from './Landingpage'
import Adminlanding from './Adminlanding'
import Userlogin from './Userlogin'
import Register from './Register'
import Drawer from '../Drawer/Drawer'
import Manageclass from '../Drawer/Manageclass'
import Editclass from './Drawer/Editclass';
import Editstudent from './Drawer/Editstudent'


function Routing() {
  return (
    <>
    <Routes>
        <Route path={"/"} element={<Landingpage/>}/>
        <Route path={"/adminlog"} element={<Adminlogin/>}/>
        <Route path={"/userlog"} element={<Userlogin/>}/>
        <Route path={"/adminpanel"} element={<Adminlanding/>}/>
        <Route path={"/reg"} element={<Register/>}/>
       
        <Route path="/manageclass" element={<Manageclass />} />
           {/* <Route path="/editclass/:id" element={<Editclass />} /> */}
           {/* <Route path="/editstudent/:id" element={<Editstudent />} /> */}


        {/* <Route path={"/drawer"} element={<Drawer/>}/> */}

    </Routes>
    </>
  )
}

export default Routing