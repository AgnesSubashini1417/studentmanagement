import { Route, Routes, useLocation } from 'react-router-dom';
import Adminlanding from './Admin/Adminlanding'
import Landingpage from './Admin/Landingpage'
import Drawer from './Drawer/Drawer';
import Adminlogin from './Admin/Adminlogin';
import Userlogin from './Admin/Userlogin';
import Register from './Admin/Register';
import Userlanding from './User/Userlanding';
import Dashboard from './Drawer/Dashboard';
import Myprof from './User/Myprof';
import Viewnotice from './User/Viewnotice';
import Editclass from './Drawer/Editclass';

import Editstudent from './Drawer/Editstudent';


function App() {
  const location = useLocation()
  console.log(location.pathname);
  const route = [
    {
      path:'/',
      Component:Landingpage
    },
    {
      path:'/adminlog',
      Component:Adminlogin
    },
    {
      path:'/userlog',
      Component:Userlogin
    },
    {
      path:'/reg',
      Component:Register
    },
   
    
   
    {
      path:"/userland",
      Component:Userlanding
    },
    {
      path:"/home",
      Component:Userlanding
    },

    {
      path:'/myprof',
      Component:Myprof
    },
    {
      path:'/Logout',
      Component:Landingpage
    },

    {
      path:'/Notice',
      Component:Viewnotice
    },
  
   
  
  ]


  const routePaths = route.map((r) => r.path);
  console.log(!routePaths.includes(location.pathname));

  return (
    <>
    <Routes>
        {
          route.map((data,index)=>(
            <Route key={index} path={data.path} element={<data.Component/>}/>
          ))
       
        }
     
        </Routes>

    {routePaths.includes(location.pathname) ? null : <Adminlanding />}
    </>
  )
}

export default App
