import React from 'react'
import { Link } from 'react-router-dom'
import "./User.css"
function Userlanding() {
  return (
    <>
    <div className="user1-main">
    <nav className="navbar-user">
        <div className="navbar-container">
            <div className="logo">Student Management System</div>
            <ul className="nav-links">
                <Link to={"/home"}><li><a href="#">Home</a></li></Link>
                {/* <li><a href="#">About us</a></li>
                <li><a href="#">Contact</a></li> */}
                <Link to={"/myprof"}><li><a href="#">My Profile</a></li></Link>
                <Link to={"/logout"}><li><a href="#">Logout</a></li></Link>
            </ul>
        </div>
    </nav>

    <div className="hero-image1">
        <div className="hero-text">
            <h1>Welcome To Student Panel</h1>
         
            <Link to={"/Notice"}><a href="#" className="cta-button">View Notices</a></Link>
        </div>
    </div>

  

    <footer className="footer">
        <div className="footer-container">
            <p>&copy; 2024 Student Management System. All rights reserved.</p>
            <ul className="footer-links">
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms of Service</a></li>
                <li><a href="#">FAQ</a></li>
            </ul>
        </div>
    </footer>
    </div>
    </>
  )
}

export default Userlanding