import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import "./myprof.css";

function Myprof() {
  const [studentData, setStudentData] = useState(null);
  const [error, setError] = useState(null);

  // Fetch student data from backend
  const fetchStudentData = async () => {
    try {
      const response = await axios.get(
        "http://localhost/studentmanagement/controllers/api/user/get/profileget.php",
        {
          withCredentials: true, // Include cookies
          validateStatus: (status) => status < 500, // Handle 401 without redirects
        }
      );
  
      if (response.status === 401) {
        setError("Unauthorized. Please log in.");
      } else if (response.data.error) {
        setError(response.data.error);
      } else if (response.data.data) {
        setStudentData(response.data.data);
      } else {
        setError("Unexpected response structure");
      }
    } catch (error) {
      console.error("Error:", error.response || error.message);
      setError("Failed to fetch student data");
    }
  };
  
  useEffect(() => {
    fetchStudentData(); // Fetch student data when the component mounts
  }, []);

  return (
    <>
      <div className="user1-main">
        <nav className="navbar-user">
          <div className="navbar-container">
            <div className="logo">Student Management System</div>
            <ul className="nav-links">
              <Link to="/home">
                <li>Home</li>
              </Link>
              <Link to="/myprof">
                <li>My Profile</li>
              </Link>
              <Link to="/logout">
                <li>Logout</li>
              </Link>
            </ul>
          </div>
        </nav>

        <div className="prof">
          <div className="t-row">
            <div className="container-mana">
              <h1 className="h1a">My Profile</h1>

              {error ? (
                <div className="error">{error}</div> // Show error if any
              ) : studentData ? (
                <table>
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Name</th>
                      <th>Class</th>
                      <th>Section</th>
                      <th>Gender</th>
                      <th>DOB</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>{studentData.studentid}</td>
                      <td>{studentData.studentname}</td>
                      <td>{studentData.studentclass}</td>
                      <td>{studentData.section}</td>
                      <td>{studentData.Gender}</td>
                      <td>{studentData.Date}</td>
                    </tr>
                  </tbody>
                </table>
              ) : (
                <p>Loading student data...</p> // Display loading state
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Myprof;
