import { useState, useEffect } from 'react';
import axios from 'axios';
import "./viewnotice.css";

const ViewNotices = () => {
  const [notices, setNotices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchNotices = async () => {
      try {
        const response = await axios.get('http://localhost/studentmanagement/controllers/api/user/get/getnotices.php', {
          withCredentials: true,  // Ensure cookies are sent with the request
        });
        setNotices(response.data.data); // Store notices in state
        setLoading(false);
      } catch (error) {
        console.error('Error fetching notices:', error);
        setError('Error fetching notices');
        setLoading(false);
      }
    };

    fetchNotices();
  }, []);

  if (loading) return <div className="loading">Loading...</div>;
  if (error) return <div className="error">{error}</div>;

  return (
    <div className="prof">
      <div className="container-tb">
        <h1 className="notice-title">Notices</h1>
        {notices.length > 0 ? (
          notices.map((notice) => (
            <div className="notice-card" key={notice.noticetitle}>
              <div className="notice-header">
                <h2>{notice.noticetitle}</h2>
                <p className="notice-date"><small>{notice.timestamp}</small></p>
              </div>
              <div className="notice-body">
                <p>{notice.noticemessage}</p>
              </div>
            </div>
          ))
        ) : (
          <p className="no-notices">No notices available for your class.</p>
        )}
      </div>
    </div>
  );
};

export default ViewNotices;
